-- Step 1: Filter and transform the base data
WITH confinements_c AS (
    SELECT 
        *,
        CASE 
            WHEN serv_to_dt > EOMONTH(GETDATE()) THEN DATEADD(DAY, 5, serv_from_dt)
            ELSE serv_to_dt
        END AS serv_to_dt_adjusted
    FROM 
        cvtenhanced_tempmedmapenroll
    WHERE 
        (
            TRY_CAST(ub92_rev_cd AS INT) BETWEEN 100 AND 219
            OR ub92_rev_cd IN ('1001', '1002')
        )
        AND place_serv_cd NOT IN (
            'SKILLED NURSING FACILITY','31','Skilled Nursing Facility',
            'SNF', '32','NURSING FACILITY','Nursing Facility','11','22'
        )
),

-- Step 2: Rename columns (aliasing for clarity)
confinements_c3 AS (
    SELECT 
        client_id,
        client_name,
        person_id,
        rend_prov_id,
        serv_from_dt,
        serv_to_dt_adjusted AS serv_to_dt,
        med_allow_chg_amt AS rb_allow_chg_amt,
        med_paid_amt AS rb_paid_amt,
        clm_chk_dt,
        rend_prov_zip_cd,
        rend_prov_nm,
        pat_stat,
        drg_code,
        place_serv_cd
    FROM 
        confinements_c
),

-- Step 3: Aggregate and retain ID fields (mimicking PROC SUMMARY with IDMIN)
confinements_c4 AS (
    SELECT 
        client_id,
        client_name,
        person_id,
        rend_prov_id,
        serv_from_dt,
        serv_to_dt,
        SUM(rb_allow_chg_amt) AS rb_allow_chg_amt,
        SUM(rb_paid_amt) AS rb_paid_amt,
        MIN(clm_chk_dt) AS clm_chk_dt,
        MIN(rend_prov_zip_cd) AS rend_prov_zip_cd,
        MIN(rend_prov_nm) AS rend_prov_nm,
        MIN(pat_stat) AS pat_stat,
        MIN(drg_code) AS drg_code,
        MIN(place_serv_cd) AS place_serv_cd
    FROM 
        confinements_c3
    GROUP BY 
        client_id,
        client_name,
        person_id,
        rend_prov_id,
        serv_from_dt,
        serv_to_dt
)

-- Final SELECT
SELECT * FROM confinements_c4;
