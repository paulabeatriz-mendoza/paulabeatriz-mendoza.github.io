-----------------------------------------
--Total Record Count & Member Count Check
-----------------------------------------
--HB Consumption
SELECT COUNT(*) AS cnt_records 
, COUNT(DISTINCT person_id) AS cnt_mems
FROM hbdbusconsumption.dbo.usndccoreinpatient
;
--Data Processing Raw Table
SELECT COUNT(*) AS cnt_records
, COUNT(DISTINCT member_id) AS cnt_mems
FROM hbdbtemp.dbo.usndccoreinpatient
;

---------------------------------------------------------
--Total Record Count, Allowed & Paid Amounts by Paid Date
---------------------------------------------------------
--HB Consumption
SELECT YEAR(conf_paid_dt) AS year
, MONTH(conf_paid_dt) AS month
, COUNT(*) AS cnt_records 
, SUM(conf_paid_amt) AS paid_amt
, SUM(conf_subm_chg_amt) AS submitted_amt
FROM hbdbusconsumption.dbo.usndccoreinpatient
GROUP BY YEAR(conf_paid_dt), MONTH(conf_paid_dt)
ORDER BY YEAR(conf_paid_dt), MONTH(conf_paid_dt)
;

--Data Processing Raw Table
SELECT YEAR(conf_paid_dt) AS year
, MONTH(conf_paid_dt) AS month
, COUNT(*) AS cnt_records 
, SUM(conf_paid_amt) AS paid_amt
, SUM(conf_subm_chg_amt) AS submitted_amt
FROM hbdbtemp.dbo.usndccoreinpatient
GROUP BY YEAR(conf_paid_dt), MONTH(conf_paid_dt)
ORDER BY YEAR(conf_paid_dt), MONTH(conf_paid_dt)
;

---------------------------------------------------------
--Total Record Count, Allowed & Paid Amounts by Age
---------------------------------------------------------
--HB Consumption
SELECT Age
, COUNT(*) AS cnt_records 
, SUM(conf_paid_amt) AS paid_amt
, SUM(conf_subm_chg_amt) AS submitted_amt
FROM hbdbusconsumption.dbo.usndccoreinpatient
GROUP BY Age
ORDER BY Age
;

SELECT Age
, COUNT(*) AS cnt_records 
, SUM(conf_paid_amt) AS paid_amt
, SUM(conf_subm_chg_amt) AS submitted_amt
FROM hbdbtemp.dbo.usndccoreinpatient
GROUP BY Age
ORDER BY Age
;

---------------------------------------------------------
--Total Record Count, Allowed & Paid Amounts by Plan Code
---------------------------------------------------------
--HB Consumption
SELECT plan_code
, COUNT(*) AS cnt_records 
, SUM(conf_paid_amt) AS paid_amt
, SUM(conf_subm_chg_amt) AS submitted_amt
FROM hbdbusconsumption.dbo.usndccoreinpatient
GROUP BY plan_code
ORDER BY plan_code
;

SELECT plan_code
, COUNT(*) AS cnt_records 
, SUM(conf_paid_amt) AS paid_amt
, SUM(conf_subm_chg_amt) AS submitted_amt
FROM hbdbtemp.dbo.usndccoreinpatient
GROUP BY plan_code
ORDER BY plan_code
;

---------------------------------------------------------
--Total Record Count, Allowed & Paid Amounts by Client Id
---------------------------------------------------------
--HB Consumption
SELECT client_id
, COUNT(*) AS cnt_records 
, SUM(conf_paid_amt) AS paid_amt
, SUM(conf_subm_chg_amt) AS submitted_amt
FROM hbdbusconsumption.dbo.usndccoreinpatient
GROUP BY client_id
ORDER BY client_id
;

SELECT client_id
, COUNT(*) AS cnt_records 
, SUM(conf_paid_amt) AS paid_amt
, SUM(conf_subm_chg_amt) AS submitted_amt
FROM hbdbtemp.dbo.usndccoreinpatient
GROUP BY client_id
ORDER BY client_id
;

---------------------------------------------------------
--Total Record Count, Allowed & Paid Amounts by Drug Code
---------------------------------------------------------
--HB Consumption
SELECT drg_code
, COUNT(*) AS cnt_records 
, SUM(conf_paid_amt) AS paid_amt
, SUM(conf_subm_chg_amt) AS submitted_amt
FROM hbdbusconsumption.dbo.usndccoreinpatient
GROUP BY drg_code
ORDER BY drg_code
;

SELECT drg_code
, COUNT(*) AS cnt_records 
, SUM(conf_paid_amt) AS paid_amt
, SUM(conf_subm_chg_amt) AS submitted_amt
FROM hbdbtemp.dbo.usndccoreinpatient
GROUP BY drg_code
ORDER BY drg_code
;