DECLARE @DB1 NVARCHAR(128) = 'hbdbtemp';
DECLARE @DB2 NVARCHAR(128) = 'hbdbusconsumption';
DECLARE @Table NVARCHAR(128) = 'usndccoremedical';
DECLARE @Column NVARCHAR(128) = 'conf_disch_dt';


DECLARE @SQL NVARCHAR(MAX);

SET @SQL = '
SELECT 
    AllValues.Value,
    ISNULL(A.CountA, 0) AS [' + @DB1 + ' Count],
    ISNULL(B.CountB, 0) AS [' + @DB2 + ' Count],
    CASE 
        WHEN A.CountA IS NOT NULL AND B.CountB IS NOT NULL THEN ''Yes''
        ELSE ''No''
    END AS IsMatch
FROM (
    SELECT DISTINCT ' + QUOTENAME(@Column) + ' AS Value FROM ' + QUOTENAME(@DB1) + '.dbo.' + QUOTENAME(@Table) + '
    UNION
    SELECT DISTINCT ' + QUOTENAME(@Column) + ' FROM ' + QUOTENAME(@DB2) + '.dbo.' + QUOTENAME(@Table) + '
) AS AllValues
LEFT JOIN (
    SELECT ' + QUOTENAME(@Column) + ', COUNT(*) AS CountA
    FROM ' + QUOTENAME(@DB1) + '.dbo.' + QUOTENAME(@Table) + '
    GROUP BY ' + QUOTENAME(@Column) + '
) AS A ON AllValues.Value = A.' + QUOTENAME(@Column) + '
LEFT JOIN (
    SELECT ' + QUOTENAME(@Column) + ', COUNT(*) AS CountB
    FROM ' + QUOTENAME(@DB2) + '.dbo.' + QUOTENAME(@Table) + '
    GROUP BY ' + QUOTENAME(@Column) + '
) AS B ON AllValues.Value = B.' + QUOTENAME(@Column) + ';
';

EXEC sp_executesql @SQL;
