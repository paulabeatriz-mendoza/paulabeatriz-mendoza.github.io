DECLARE @DB1 NVARCHAR(128) = 'hbdbtemp';
DECLARE @DB2 NVARCHAR(128) = 'hbdbusconsumption';
DECLARE @Table NVARCHAR(128) = 'usndccorerxclaim';

DECLARE @Index INT = 1;
DECLARE @Total INT;
DECLARE @ColumnName NVARCHAR(128);
DECLARE @SQL NVARCHAR(MAX);

-- Get total number of distinct columns from both databases
SELECT @Total = COUNT(*) FROM (
    SELECT COLUMN_NAME FROM [hbdbtemp].INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = @Table
    UNION
    SELECT COLUMN_NAME FROM [hbdbusconsumption].INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = @Table
) AS AllCols;

-- Loop through each column by index
WHILE @Index <= @Total
BEGIN
    SELECT @ColumnName = COLUMN_NAME
    FROM (
        SELECT ROW_NUMBER() OVER (ORDER BY COLUMN_NAME) AS RowNum, COLUMN_NAME
        FROM (
            SELECT COLUMN_NAME FROM [hbdbtemp].INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = @Table
            UNION
            SELECT COLUMN_NAME FROM [hbdbusconsumption].INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = @Table
        ) AS AllCols
    ) AS OrderedCols
    WHERE RowNum = @Index;

    DECLARE @ExistsInDB1 BIT = 0, @ExistsInDB2 BIT = 0;

    IF EXISTS (
        SELECT 1 FROM [hbdbtemp].INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_NAME = @Table AND COLUMN_NAME = @ColumnName
    ) SET @ExistsInDB1 = 1;

    IF EXISTS (
        SELECT 1 FROM [hbdbusconsumption].INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_NAME = @Table AND COLUMN_NAME = @ColumnName
    ) SET @ExistsInDB2 = 1;

    SET @SQL = 'PRINT ''Comparing column: ' + @ColumnName + ''';' + CHAR(13);
    SET @SQL += 'SELECT ''' + @ColumnName + ''' AS ColumnName, AllValues.Value, ';

    IF @ExistsInDB1 = 1
        SET @SQL += 'ISNULL(A.CountA, 0) AS [' + @DB1 + ' Count], ';
    ELSE
        SET @SQL += '''Unavailable'' AS [' + @DB1 + ' Count], ';

    IF @ExistsInDB2 = 1
        SET @SQL += 'ISNULL(B.CountB, 0) AS [' + @DB2 + ' Count], ';
    ELSE
        SET @SQL += '''Unavailable'' AS [' + @DB2 + ' Count], ';

    -- Add CountDifference column
    SET @SQL += 
        CASE 
            WHEN @ExistsInDB1 = 1 AND @ExistsInDB2 = 1 THEN 
                'ABS(ISNULL(A.CountA, 0) - ISNULL(B.CountB, 0)) AS CountDifference, '
            ELSE 
                '''Unavailable'' AS CountDifference, '
        END;

    -- Add MatchOrder column for ordering
    SET @SQL += 
        'CASE WHEN ' + 
        CASE 
            WHEN @ExistsInDB1 = 1 AND @ExistsInDB2 = 1 THEN 'ISNULL(A.CountA, 0) = ISNULL(B.CountB, 0)' 
            ELSE '0=1' 
        END + 
        ' THEN 1 ELSE 0 END AS MatchOrder, ';

    -- Add IsMatch column
    SET @SQL += 
        'CASE WHEN ' + 
        CASE 
            WHEN @ExistsInDB1 = 1 AND @ExistsInDB2 = 1 THEN 'ISNULL(A.CountA, 0) = ISNULL(B.CountB, 0)' 
            ELSE '0=1' 
        END + 
        ' THEN ''Yes'' ELSE ''No'' END AS IsMatch
    FROM (';

    IF @ExistsInDB1 = 1
        SET @SQL += '
        SELECT DISTINCT 
            CASE 
                WHEN ' + QUOTENAME(@ColumnName) + ' IS NULL THEN ''[NULL]'' 
                ELSE CAST(' + QUOTENAME(@ColumnName) + ' AS NVARCHAR(MAX)) 
            END AS Value 
        FROM ' + QUOTENAME(@DB1) + '.dbo.' + QUOTENAME(@Table);

    IF @ExistsInDB1 = 1 AND @ExistsInDB2 = 1
        SET @SQL += ' UNION ';

    IF @ExistsInDB2 = 1
        SET @SQL += '
        SELECT DISTINCT 
            CASE 
                WHEN ' + QUOTENAME(@ColumnName) + ' IS NULL THEN ''[NULL]'' 
                ELSE CAST(' + QUOTENAME(@ColumnName) + ' AS NVARCHAR(MAX)) 
            END AS Value 
        FROM ' + QUOTENAME(@DB2) + '.dbo.' + QUOTENAME(@Table);

    IF @ExistsInDB1 = 0 AND @ExistsInDB2 = 0
        SET @SQL += 'SELECT NULL AS Value';

    SET @SQL += ') AS AllValues ';

    IF @ExistsInDB1 = 1
        SET @SQL += '
        LEFT JOIN (
            SELECT 
                CASE 
                    WHEN ' + QUOTENAME(@ColumnName) + ' IS NULL THEN ''[NULL]'' 
                    ELSE CAST(' + QUOTENAME(@ColumnName) + ' AS NVARCHAR(MAX)) 
                END AS Value,
                COUNT(*) AS CountA
            FROM ' + QUOTENAME(@DB1) + '.dbo.' + QUOTENAME(@Table) + '
            GROUP BY 
                CASE 
                    WHEN ' + QUOTENAME(@ColumnName) + ' IS NULL THEN ''[NULL]'' 
                    ELSE CAST(' + QUOTENAME(@ColumnName) + ' AS NVARCHAR(MAX)) 
                END
        ) AS A ON AllValues.Value = A.Value';

    IF @ExistsInDB2 = 1
        SET @SQL += '
        LEFT JOIN (
            SELECT 
                CASE 
                    WHEN ' + QUOTENAME(@ColumnName) + ' IS NULL THEN ''[NULL]'' 
                    ELSE CAST(' + QUOTENAME(@ColumnName) + ' AS NVARCHAR(MAX)) 
                END AS Value,
                COUNT(*) AS CountB
            FROM ' + QUOTENAME(@DB2) + '.dbo.' + QUOTENAME(@Table) + '
            GROUP BY 
                CASE 
                    WHEN ' + QUOTENAME(@ColumnName) + ' IS NULL THEN ''[NULL]'' 
                    ELSE CAST(' + QUOTENAME(@ColumnName) + ' AS NVARCHAR(MAX)) 
                END
        ) AS B ON AllValues.Value = B.Value';

    SET @SQL += '
    ORDER BY MatchOrder, AllValues.Value;';

    EXEC sp_executesql @SQL;

    SET @Index += 1;
END
