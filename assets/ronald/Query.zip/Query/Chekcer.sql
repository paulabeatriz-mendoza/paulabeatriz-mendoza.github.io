SELECT top 100 a.sn,a.MemID,b.sn,b.MemID,a.risk_score,b.risk_score
FROM [hbdbtemp].[dbo].[usndccoremedical] a
JOIN [hbdbusconsumption].[dbo].[usndccoremedical] b
    ON a.sn = b.sn
WHERE a.risk_score <> b.risk_score