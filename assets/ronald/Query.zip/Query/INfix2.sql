-- Step 1: Filter and transform the base data
WITH confinements_c AS (
    SELECT 
        *,
        CASE 
            WHEN serv_to_dt > EOMONTH(GETDATE()) THEN DATEADD(DAY, 5, serv_from_dt)
            ELSE serv_to_dt
        END AS serv_to_dt_adjusted
    FROM 
        cvtenhanced_tempmedmapenroll
    WHERE 
        (
            TRY_CAST(ub92_rev_cd AS INT) BETWEEN 100 AND 219
            OR ub92_rev_cd IN ('1001', '1002')
        )
        AND place_serv_cd NOT IN (
            'SKILLED NURSING FACILITY','31','Skilled Nursing Facility',
            'SNF', '32','NURSING FACILITY','Nursing Facility','11','22'
        )
),

-- Step 2: Rename columns (aliasing for clarity)
confinements_c3 AS (
    SELECT 
        client_id,
        client_name,
        person_id,
        rend_prov_id,
        serv_from_dt,
        serv_to_dt_adjusted AS serv_to_dt,
        med_allow_chg_amt AS rb_allow_chg_amt,
        med_cob_amt AS rb_cob_amt,
        med_coins_amt AS rb_coins_amt,
        med_copay_amt AS rb_copay_amt,
        med_deduct_amt AS rb_deduct_amt,
        med_disc_amt AS rb_disc_amt,
        med_paid_amt AS rb_paid_amt,
        med_subm_chg_amt AS rb_subm_chg_amt,
        med_non_covd_chg_amt AS rb_non_covd_chg_amt,
        clm_chk_dt,
        rend_prov_zip_cd,
        rend_prov_nm,
        pat_stat,
        drg_code,
        place_serv_cd
    FROM 
        confinements_c
),

-- Step 3: Aggregate and join back
confinements_c4 AS (
    SELECT 
        a.client_id,
        a.client_name,
        a.person_id,
        a.rend_prov_id,
        a.serv_from_dt,
        a.serv_to_dt,
        a.rb_allow_chg_amt,
        a.rb_paid_amt,
        b.clm_chk_dt,
        b.rend_prov_zip_cd,
        b.rend_prov_nm,
        b.pat_stat,
        b.drg_code,
        b.place_serv_cd
    FROM (
        SELECT 
            client_id,
            client_name,
            person_id,
            rend_prov_id,
            serv_from_dt,
            serv_to_dt,
            SUM(rb_allow_chg_amt) AS rb_allow_chg_amt,
            SUM(rb_paid_amt) AS rb_paid_amt
        FROM 
            confinements_c3
        GROUP BY 
            client_id, client_name, person_id, rend_prov_id, serv_from_dt, serv_to_dt
    ) AS a
    LEFT JOIN confinements_c3 AS b
        ON a.client_id = b.client_id
        AND a.client_name = b.client_name
        AND a.person_id = b.person_id
        AND a.rend_prov_id = b.rend_prov_id
        AND a.serv_from_dt = b.serv_from_dt
        AND a.serv_to_dt = b.serv_to_dt
)

-- Final SELECT
SELECT * FROM confinements_c4;
