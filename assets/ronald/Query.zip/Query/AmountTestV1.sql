DECLARE @columnList NVARCHAR(MAX) = 'conf_Subm_Chg_Amt,conf_Paid_Amt,conf_Coins_Amt,conf_Copay_Amt,conf_COB_Amt,conf_Deduct_Amt';
DECLARE @table1 NVARCHAR(MAX) = 'hbdbusconsumption.dbo.cvtenhancedinpatient';
DECLARE @table2 NVARCHAR(MAX) = 'hbdbtemp.dbo.cvtenhancedinpatient';
DECLARE @sql NVARCHAR(MAX) = '';

-- Build the dynamic SQL using STRING_SPLIT and STRING_AGG
SELECT @sql = STRING_AGG('
SELECT 
    ''' + value + ''' AS ColumnName,
    (SELECT SUM(TRY_CAST(' + QUOTENAME(value) + ' AS FLOAT)) FROM ' + @table1 + ') AS consumption_total_sum,
    (SELECT SUM(TRY_CAST(' + QUOTENAME(value) + ' AS FLOAT)) FROM ' + @table2 + ') AS temp_total_sum,
    (SELECT SUM(TRY_CAST(' + QUOTENAME(value) + ' AS FLOAT)) FROM ' + @table1 + ') -
    (SELECT SUM(TRY_CAST(' + QUOTENAME(value) + ' AS FLOAT)) FROM ' + @table2 + ') AS difference,
    CASE 
        WHEN (SELECT SUM(TRY_CAST(' + QUOTENAME(value) + ' AS FLOAT)) FROM ' + @table2 + ') = 0 THEN NULL
        ELSE ROUND(
            (
                (SELECT SUM(TRY_CAST(' + QUOTENAME(value) + ' AS FLOAT)) FROM ' + @table1 + ') -
                (SELECT SUM(TRY_CAST(' + QUOTENAME(value) + ' AS FLOAT)) FROM ' + @table2 + ')
            ) * 100.0 / 
            (SELECT SUM(TRY_CAST(' + QUOTENAME(value) + ' AS FLOAT)) FROM ' + @table2 + ')
        , 3)
    END AS Variance_percentage'
, '
UNION ALL
')
FROM STRING_SPLIT(@columnList, ',');

-- Execute the final dynamic SQL
EXEC sp_executesql @sql;
