DECLARE @columnList NVARCHAR(MAX) = 'conf_Subm_Chg_Amt,conf_Paid_Amt,conf_Coins_Amt,conf_Copay_Amt,conf_COB_Amt,conf_Deduct_Amt';
DECLARE @table1 NVARCHAR(MAX) = 'hbdbusconsumption.dbo.cvtenhancedinpatient';
DECLARE @table2 NVARCHAR(MAX) = 'hbdbtemp.dbo.cvtenhancedinpatient';
DECLARE @groupByColumn NVARCHAR(MAX) = 'conf_drg_analytic_cd'; -- Replace with actual column name
DECLARE @sql NVARCHAR(MAX) = '';

-- Build the dynamic SQL
SELECT @sql = STRING_AGG('
SELECT 
    ''' + value + ''' AS ColumnName,
    ISNULL(cons.' + QUOTENAME(@groupByColumn) + ', temp.' + QUOTENAME(@groupByColumn) + ') AS ' + QUOTENAME(@groupByColumn) + ',
    ISNULL(cons.total_sum, 0) AS consumption_total_sum,
    ISNULL(temp.total_sum, 0) AS temp_total_sum,
    ISNULL(cons.total_sum, 0) - ISNULL(temp.total_sum, 0) AS difference,
    CASE 
        WHEN (SELECT SUM(TRY_CAST(' + QUOTENAME(value) + ' AS FLOAT)) FROM ' + @table2 + ') = 0 THEN NULL
        ELSE ROUND(
            (ISNULL(cons.total_sum, 0) - ISNULL(temp.total_sum, 0)) * 1.0 /
            (SELECT SUM(TRY_CAST(' + QUOTENAME(value) + ' AS FLOAT)) FROM ' + @table2 + ')
        , 3)
    END AS variance_percentage
FROM (
    SELECT ' + QUOTENAME(@groupByColumn) + ', SUM(TRY_CAST(' + QUOTENAME(value) + ' AS FLOAT)) AS total_sum
    FROM ' + @table1 + '
    GROUP BY ' + QUOTENAME(@groupByColumn) + '
) cons
FULL OUTER JOIN (
    SELECT ' + QUOTENAME(@groupByColumn) + ', SUM(TRY_CAST(' + QUOTENAME(value) + ' AS FLOAT)) AS total_sum
    FROM ' + @table2 + '
    GROUP BY ' + QUOTENAME(@groupByColumn) + '
) temp
ON cons.' + QUOTENAME(@groupByColumn) + ' = temp.' + QUOTENAME(@groupByColumn) + '
', '
UNION ALL
')
FROM STRING_SPLIT(@columnList, ',');

-- Execute the final dynamic SQL
EXEC sp_executesql @sql;
