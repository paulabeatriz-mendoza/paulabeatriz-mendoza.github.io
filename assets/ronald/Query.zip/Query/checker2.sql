SELECT top 100  *
FROM hbdbusconsumption.dbo.cvtenhancedeligibility where  bus_unit in ('N/A')

SELECT top 100 *
FROM hbdbtemp.dbo.cvtenhancedeligibility  where bus_unit in ('N/A')