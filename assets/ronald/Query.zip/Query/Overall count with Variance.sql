DECLARE @TBL1 NVARCHAR(128) = 'usartemismedical';
DECLARE @SQL NVARCHAR(MAX);

SET @SQL = 
'SELECT
    COUNT_BUS AS Consumption_Count,
    COUNT_TEMP AS Temp_Count,
    COUNT_TEMP - COUNT_BUS AS Difference,
    CAST(COUNT_TEMP - COUNT_BUS AS FLOAT) / NULLIF(COUNT_TEMP, 0) AS Variance,
    FORMAT(
        CAST(COUNT_TEMP - COUNT_BUS AS FLOAT) / NULLIF(COUNT_TEMP, 0) * 100, 
        ''N3''
    ) + ''%'' AS VariancePercentage
FROM (
    SELECT 
        (SELECT COUNT(*) FROM hbdbusconsumption.dbo.' + @TBL1 +') AS COUNT_BUS,
        (SELECT COUNT(*) FROM hbdbtemp.dbo.' + @TBL1 + ') AS COUNT_TEMP
) AS Counts;'

    EXEC sp_executesql @SQL;