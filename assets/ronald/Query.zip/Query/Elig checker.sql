SELECT top 100 
	a.memid AS a_memid,
    b.memid AS b_memid,
    a.empid AS a_empid,
    b.empid AS b_empid,
    a.dob AS a_dob,
    b.dob AS b_dob,
    a.age AS a_age,
    b.age AS b_age,
    a.age_v AS a_age_v,
    b.age_v AS b_age_v,
	a.coverage_month  as a_coverage_month,
	b.coverage_month  as b_coverage_month,
	a.coverage_year as A_coverage_year,
	b.coverage_year as b_coverage_year,
	a.coverage_mth_id as a_coverage_mth_id,
	b.coverage_mth_id as b_coverage_mth_id,

	a.Carrier_Name_ID AS a_Carrier_Name_ID, 
	b.Carrier_Name_ID AS b_Carrier_Name_ID 


FROM [hbdbtemp].[dbo].[cvtenhancedeligibility] a
JOIN [hbdbusconsumption].[dbo].[cvtenhancedeligibility] b
ON a.memid = b.memid
 AND a.empid = b.empid
 AND a.age = b.age
 AND a.age_v = b.age_v
 and a.coverage_mth_id = b.coverage_mth_id
 and a.coverage_year = b.coverage_year

WHERE a.Carrier_Name_ID <> b.Carrier_Name_ID