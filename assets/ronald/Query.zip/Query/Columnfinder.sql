DECLARE @TableName NVARCHAR(128) = 'uswillismedrxclaim';
DECLARE @Keyword NVARCHAR(128) = '%Amt%';

DECLARE @SQL NVARCHAR(MAX);

SET @SQL = '
SELECT ''hbdbtemp'' AS DatabaseName, COLUMN_NAME
FROM hbdbtemp.INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = @TableName AND COLUMN_NAME LIKE @Keyword

UNION ALL
SELECT ''hbdbusconsumption'' AS DatabaseName, COLUMN_NAME
FROM hbdbusconsumption.INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = @TableName AND COLUMN_NAME LIKE @Keyword;
';

EXEC sp_executesql @SQL, 
    N'@TableName NVARCHAR(128), @Keyword NVARCHAR(128)', 
    @TableName, @Keyword;
