use Hbdbusconsumption
DECLARE @TableName NVARCHAR(100) = 'usartemismedical';
DECLARE @SchemaName NVARCHAR(MAX) = 'dbo'; -- Replace with your schema name
DECLARE @SQL NVARCHAR(MAX) = '';

SELECT @SQL = STRING_AGG('
SELECT 
    ''' + COLUMN_NAME + ''' AS ColumnName,
    COUNT(*) AS TotalRows,
    COUNT([' + COLUMN_NAME + ']) AS NonBlankCount,
    COUNT(*) - COUNT([' + COLUMN_NAME + ']) AS BlankCount,
    COUNT(DISTINCT [' + COLUMN_NAME + ']) AS DistinctCount
FROM [' + @SchemaName + '].[' + @TableName + ']', '
UNION ALL
')
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = @TableName AND TABLE_SCHEMA = @SchemaName;

-- Execute the dynamic SQL
EXEC sp_executesql @SQL;

use Hbdbtemp
SELECT @SQL = STRING_AGG('
SELECT 
    ''' + COLUMN_NAME + ''' AS ColumnName,
    COUNT(*) AS TotalRows,
    COUNT([' + COLUMN_NAME + ']) AS NonBlankCount,
    COUNT(*) - COUNT([' + COLUMN_NAME + ']) AS BlankCount,
    COUNT(DISTINCT [' + COLUMN_NAME + ']) AS DistinctCount
FROM [' + @SchemaName + '].[' + @TableName + ']', '
UNION ALL
')
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = @TableName AND TABLE_SCHEMA = @SchemaName;

-- Execute the dynamic SQL
EXEC sp_executesql @SQL;