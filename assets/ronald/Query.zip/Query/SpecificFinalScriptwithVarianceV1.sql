DECLARE @DB1 NVARCHAR(128) = 'hbdbtemp';
DECLARE @DB2 NVARCHAR(128) = 'hbdbusconsumption';
DECLARE @Table NVARCHAR(128) = 'usndccorerxclaim';

DECLARE @ColumnList NVARCHAR(MAX) = 'UDF3_RXVENDOR,union_ind,WarningFlag,WarningReason,work_location';
DECLARE @ColumnName NVARCHAR(128);
DECLARE @SQL NVARCHAR(MAX);

DECLARE @Divisor INT = 10; -- Set your manual divisor value here
DECLARE @FormatAsPercent BIT = 1; -- Set to 1 to format as percentage, 0 for raw decimal
DECLARE @DecimalPlaces INT = 3; -- Set how many decimal places to show in Variance

WHILE LEN(@ColumnList) > 0
BEGIN
    IF CHARINDEX(',', @ColumnList) > 0
    BEGIN
        SET @ColumnName = LTRIM(RTRIM(LEFT(@ColumnList, CHARINDEX(',', @ColumnList) - 1)));
        SET @ColumnList = RIGHT(@ColumnList, LEN(@ColumnList) - CHARINDEX(',', @ColumnList));
    END
    ELSE
    BEGIN
        SET @ColumnName = LTRIM(RTRIM(@ColumnList));
        SET @ColumnList = '';
    END

    DECLARE @ExistsInDB1 BIT = 0, @ExistsInDB2 BIT = 0;

    IF EXISTS (
        SELECT 1 FROM [hbdbtemp].INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_NAME = @Table AND COLUMN_NAME = @ColumnName
    ) SET @ExistsInDB1 = 1;

    IF EXISTS (
        SELECT 1 FROM [hbdbusconsumption].INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_NAME = @Table AND COLUMN_NAME = @ColumnName
    ) SET @ExistsInDB2 = 1;

    SET @SQL = 'PRINT ''Comparing column: ' + @ColumnName + ''';' + CHAR(13);
    SET @SQL += 'SELECT ''' + @ColumnName + ''' AS ColumnName, AllValues.Value, ';

    IF @ExistsInDB1 = 1
        SET @SQL += 'ISNULL(A.CountA, 0) AS [' + @DB1 + ' Count], ';
    ELSE
        SET @SQL += '''Unavailable'' AS [' + @DB1 + ' Count], ';

    IF @ExistsInDB2 = 1
        SET @SQL += 'ISNULL(B.CountB, 0) AS [' + @DB2 + ' Count], ';
    ELSE
        SET @SQL += '''Unavailable'' AS [' + @DB2 + ' Count], ';

    -- CountDifference
    SET @SQL += 
        CASE 
            WHEN @ExistsInDB1 = 1 AND @ExistsInDB2 = 1 THEN 
                'ABS(ISNULL(A.CountA, 0) - ISNULL(B.CountB, 0)) AS CountDifference, '
            ELSE 
                '''Unavailable'' AS CountDifference, '
        END;

    -- Variance (formerly NormalizedDifference)
    SET @SQL += 
        CASE 
            WHEN @ExistsInDB1 = 1 AND @ExistsInDB2 = 1 THEN 
                'CASE WHEN ' + CONVERT(NVARCHAR, @FormatAsPercent) + ' = 1 THEN ' +
                'FORMAT(CAST(ABS(ISNULL(A.CountA, 0) - ISNULL(B.CountB, 0)) AS FLOAT) / ' + CAST(@Divisor AS NVARCHAR) + ' * 100, ''N' + CAST(@DecimalPlaces AS NVARCHAR) + ''') + ''%'' ' +
                'ELSE FORMAT(CAST(ABS(ISNULL(A.CountA, 0) - ISNULL(B.CountB, 0)) AS FLOAT) / ' + CAST(@Divisor AS NVARCHAR) + ', ''N' + CAST(@DecimalPlaces AS NVARCHAR) + ''') END AS Variance, '
            ELSE 
                '''Unavailable'' AS Variance, '
        END;

    -- SortOrder
    SET @SQL += '
    CASE 
        WHEN ' + 
        CASE WHEN @ExistsInDB1 = 1 THEN 'A.CountA IS NULL' ELSE '1=0' END + 
        ' OR ' + 
        CASE WHEN @ExistsInDB2 = 1 THEN 'B.CountB IS NULL' ELSE '1=0' END + 
        ' THEN 0 ELSE 1 END AS SortOrder, ';

    -- IsMatch (moved to the end)
    SET @SQL += '
    CASE 
        WHEN ' + 
        CASE 
            WHEN @ExistsInDB1 = 1 AND @ExistsInDB2 = 1 THEN 'ISNULL(A.CountA, 0) = ISNULL(B.CountB, 0)' 
            ELSE '0=1' 
        END + 
        ' THEN ''Yes'' ELSE ''No'' END AS IsMatch
    FROM (';

    IF @ExistsInDB1 = 1
        SET @SQL += '
        SELECT DISTINCT 
            CASE 
                WHEN ' + QUOTENAME(@ColumnName) + ' IS NULL THEN ''[NULL]'' 
                ELSE CAST(' + QUOTENAME(@ColumnName) + ' AS NVARCHAR(MAX)) 
            END AS Value 
        FROM ' + QUOTENAME(@DB1) + '.dbo.' + QUOTENAME(@Table);

    IF @ExistsInDB1 = 1 AND @ExistsInDB2 = 1
        SET @SQL += ' UNION ';

    IF @ExistsInDB2 = 1
        SET @SQL += '
        SELECT DISTINCT 
            CASE 
                WHEN ' + QUOTENAME(@ColumnName) + ' IS NULL THEN ''[NULL]'' 
                ELSE CAST(' + QUOTENAME(@ColumnName) + ' AS NVARCHAR(MAX)) 
            END AS Value 
        FROM ' + QUOTENAME(@DB2) + '.dbo.' + QUOTENAME(@Table);

    IF @ExistsInDB1 = 0 AND @ExistsInDB2 = 0
        SET @SQL += 'SELECT NULL AS Value';

    SET @SQL += ') AS AllValues ';

    IF @ExistsInDB1 = 1
        SET @SQL += '
        LEFT JOIN (
            SELECT 
                CASE 
                    WHEN ' + QUOTENAME(@ColumnName) + ' IS NULL THEN ''[NULL]'' 
                    ELSE CAST(' + QUOTENAME(@ColumnName) + ' AS NVARCHAR(MAX)) 
                END AS Value,
                COUNT(*) AS CountA
            FROM ' + QUOTENAME(@DB1) + '.dbo.' + QUOTENAME(@Table) + '
            GROUP BY 
                CASE 
                    WHEN ' + QUOTENAME(@ColumnName) + ' IS NULL THEN ''[NULL]'' 
                    ELSE CAST(' + QUOTENAME(@ColumnName) + ' AS NVARCHAR(MAX)) 
                END
        ) AS A ON AllValues.Value = A.Value';

    IF @ExistsInDB2 = 1
        SET @SQL += '
        LEFT JOIN (
            SELECT 
                CASE 
                    WHEN ' + QUOTENAME(@ColumnName) + ' IS NULL THEN ''[NULL]'' 
                    ELSE CAST(' + QUOTENAME(@ColumnName) + ' AS NVARCHAR(MAX)) 
                END AS Value,
                COUNT(*) AS CountB
            FROM ' + QUOTENAME(@DB2) + '.dbo.' + QUOTENAME(@Table) + '
            GROUP BY 
                CASE 
                    WHEN ' + QUOTENAME(@ColumnName) + ' IS NULL THEN ''[NULL]'' 
                    ELSE CAST(' + QUOTENAME(@ColumnName) + ' AS NVARCHAR(MAX)) 
                END
        ) AS B ON AllValues.Value = B.Value';

    SET @SQL += '
    ORDER BY IsMatch, AllValues.Value;';

    EXEC sp_executesql @SQL;
END
