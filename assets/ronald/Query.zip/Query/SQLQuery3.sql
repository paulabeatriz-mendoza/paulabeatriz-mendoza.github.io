DECLARE @TableName NVARCHAR(128) = 'stageusndccore'+'Druglookup'; -- Full table name
DECLARE @SchemaName NVARCHAR(128) = 'dbo';
DECLARE @GroupByColumn NVARCHAR(128) = 'ExecutionID'; -- Set to NULL or '' to disable grouping
DECLARE @SQL NVARCHAR(MAX) = '';

-- Build dynamic SQL for each column
SELECT @SQL = STRING_AGG(CAST('
-- Non-null count
SELECT 
    ''' + @TableName + ''' AS TableName,
    ''' + c.name + ''' AS ColumnName,
    ''NonNullCount'' AS Metric,
    COUNT([' + c.name + ']) AS Value' +
    CASE 
        WHEN @GroupByColumn IS NOT NULL AND @GroupByColumn <> '' 
        THEN ', [' + @GroupByColumn + '] AS GroupByValue' 
        ELSE '' 
    END + '
FROM [' + @SchemaName + '].[' + @TableName + ']' +
    CASE 
        WHEN @GroupByColumn IS NOT NULL AND @GroupByColumn <> '' 
        THEN ' GROUP BY [' + @GroupByColumn + ']' 
        ELSE '' 
    END + '

UNION ALL

-- Distinct count
SELECT 
    ''' + @TableName + ''' AS TableName,
    ''' + c.name + ''' AS ColumnName,
    ''DistinctCount'' AS Metric,
    COUNT(DISTINCT [' + c.name + ']) AS Value' +
    CASE 
        WHEN @GroupByColumn IS NOT NULL AND @GroupByColumn <> '' 
        THEN ', [' + @GroupByColumn + '] AS GroupByValue' 
        ELSE '' 
    END + '
FROM [' + @SchemaName + '].[' + @TableName + ']' +
    CASE 
        WHEN @GroupByColumn IS NOT NULL AND @GroupByColumn <> '' 
        THEN ' GROUP BY [' + @GroupByColumn + ']' 
        ELSE '' 
    END + '

UNION ALL

-- Group by distinct values
SELECT 
    ''' + @TableName + ''' AS TableName,
    ''' + c.name + ''' AS ColumnName,
    CAST([' + c.name + '] AS NVARCHAR(MAX)) AS Metric,
    COUNT(*) AS Value' +
    CASE 
        WHEN @GroupByColumn IS NOT NULL AND @GroupByColumn <> '' 
        THEN ', [' + @GroupByColumn + '] AS GroupByValue' 
        ELSE '' 
    END + '
FROM [' + @SchemaName + '].[' + @TableName + ']' +
    CASE 
        WHEN @GroupByColumn IS NOT NULL AND @GroupByColumn <> '' 
        THEN ' GROUP BY [' + c.name + '], [' + @GroupByColumn + ']' 
        ELSE ' GROUP BY [' + c.name + ']' 
    END AS NVARCHAR(MAX)), 
CHAR(13) + 'UNION ALL' + CHAR(13))
FROM sys.columns c
JOIN sys.tables t ON c.object_id = t.object_id
JOIN sys.schemas s ON t.schema_id = s.schema_id
WHERE t.name = @TableName AND s.name = @SchemaName;

-- Add total row count
SET @SQL += '
UNION ALL
SELECT 
    ''' + @TableName + ''' AS TableName,
    ''(Total Rows)'' AS ColumnName,
    ''TotalRowCount'' AS Metric,
    COUNT(*) AS Value' +
    CASE 
        WHEN @GroupByColumn IS NOT NULL AND @GroupByColumn <> '' 
        THEN ', [' + @GroupByColumn + '] AS GroupByValue' 
        ELSE '' 
    END + '
FROM [' + @SchemaName + '].[' + @TableName + ']' +
    CASE 
        WHEN @GroupByColumn IS NOT NULL AND @GroupByColumn <> '' 
        THEN ' GROUP BY [' + @GroupByColumn + ']' 
        ELSE '' 
    END;

-- Remove trailing UNION ALL if present
IF RIGHT(LTRIM(RTRIM(@SQL)), 10) = 'UNION ALL'
    SET @SQL = LEFT(@SQL, LEN(@SQL) - 10);

-- Execute the dynamic SQL
EXEC sp_executesql @SQL;
