DECLARE @DatabaseName NVARCHAR(128) = 'hbdbstage';
DECLARE @TableName NVARCHAR(128) = 'stageuscotivitiwillismedmemberdxcg';
DECLARE @SchemaName NVARCHAR(128) = 'dbo';
DECLARE @SQL NVARCHAR(MAX);
DECLARE @ColumnName NVARCHAR(128);
DECLARE @ColumnList NVARCHAR(MAX);

-- Get the list of column names as a comma-separated string
SELECT @ColumnList = STRING_AGG(QUOTENAME(COLUMN_NAME), ',')
FROM hbdbstage.INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = @TableName AND TABLE_SCHEMA = @SchemaName;

-- Loop through each column name using string manipulation
WHILE LEN(@ColumnList) > 0
BEGIN
    -- Extract the next column name
    SET @ColumnName = LTRIM(RTRIM(SUBSTRING(@ColumnList, 1, CHARINDEX(',', @ColumnList + ',') - 1)));

    -- Remove the processed column from the list
    SET @ColumnList = STUFF(@ColumnList, 1, CHARINDEX(',', @ColumnList + ','), '');

    -- Build and execute the SQL for this column
    SET @SQL = '
        SELECT ''' + @ColumnName + ''' AS column_name,
               ISNULL(TRY_CONVERT(NVARCHAR(MAX), ' + @ColumnName + '), ''[NULL]'') AS value,
               COUNT(*) AS count
        FROM [' + @DatabaseName + '].[' + @SchemaName + '].[' + @TableName + ']
        GROUP BY ISNULL(TRY_CONVERT(NVARCHAR(MAX), ' + @ColumnName + '), ''[NULL]'')
        ORDER BY COUNT(*) DESC;
    ';

    PRINT 'Executing for column: ' + @ColumnName;
    EXEC sp_executesql @SQL;
END
