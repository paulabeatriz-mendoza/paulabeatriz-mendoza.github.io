DECLARE @Keyword NVARCHAR(100) = 'ctv';

SELECT 
    s.name AS SchemaName,
    et.name AS ExternalTableName,
    ac.name AS ColumnName,
    ty.name AS DataType
FROM 
    sys.external_tables et
JOIN 
    sys.schemas s ON et.schema_id = s.schema_id
JOIN 
    sys.all_columns ac ON et.object_id = ac.object_id
JOIN 
    sys.types ty ON ac.user_type_id = ty.user_type_id
WHERE 
    et.name LIKE '%' + @Keyword + '%'
ORDER BY 
    s.name, et.name, ac.column_id;
