-- =========================
-- CONFIGURABLE PARAMETERS
-- =========================
DECLARE @dbA NVARCHAR(128) = 'hbdbtemp';
DECLARE @schemaA NVARCHAR(128) = 'dbo';
DECLARE @tableA NVARCHAR(128) = 'usndccoremedical';

DECLARE @dbB NVARCHAR(128) = 'hbdbusconsumption';
DECLARE @schemaB NVARCHAR(128) = 'dbo';
DECLARE @tableB NVARCHAR(128) = 'usndccoremedical';

-- =========================
-- INTERNAL VARIABLES
-- =========================
DECLARE @sql NVARCHAR(MAX) = '';
DECLARE @columns NVARCHAR(MAX) = '';

-- =========================
-- GET COMMON COLUMNS
-- =========================
;WITH colsA AS (
    SELECT c.name
    FROM [hbdbtemp].sys.columns c
    JOIN [hbdbtemp].sys.tables t ON c.object_id = t.object_id
    WHERE t.name = @tableA AND SCHEMA_NAME(t.schema_id) = @schemaA
),
colsB AS (
    SELECT c.name
    FROM [hbdbusconsumption].sys.columns c
    JOIN [hbdbusconsumption].sys.tables t ON c.object_id = t.object_id
    WHERE t.name = @tableB AND SCHEMA_NAME(t.schema_id) = @schemaB
),
commonCols AS (
    SELECT a.name
    FROM colsA a
    INNER JOIN colsB b ON a.name = b.name
)
SELECT @columns = STRING_AGG(
    CAST(
        '(a.' + QUOTENAME(name) + ' <> b.' + QUOTENAME(name) +
        ' OR (a.' + QUOTENAME(name) + ' IS NULL AND b.' + QUOTENAME(name) + ' IS NOT NULL)' +
        ' OR (a.' + QUOTENAME(name) + ' IS NOT NULL AND b.' + QUOTENAME(name) + ' IS NULL))'
        AS NVARCHAR(MAX)
    ),
    ' OR '
)
FROM commonCols;

-- =========================
-- BUILD FINAL SQL
-- =========================
SET @sql = '
SELECT a.sn, b.sn
FROM [' + @dbA + '].[' + @schemaA + '].[' + @tableA + '] a
JOIN [' + @dbB + '].[' + @schemaB + '].[' + @tableB + '] b
    ON a.sn = b.sn
WHERE ' + ISNULL(@columns, '1 = 0') + '
';

-- =========================
-- OUTPUT OR EXECUTE
-- =========================
--PRINT @sql;
 EXEC sp_executesql @sql;
